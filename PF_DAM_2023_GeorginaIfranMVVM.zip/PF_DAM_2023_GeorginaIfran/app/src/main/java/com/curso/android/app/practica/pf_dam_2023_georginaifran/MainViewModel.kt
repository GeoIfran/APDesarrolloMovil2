package com.curso.android.app.practica.pf_dam_2023_georginaifran

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainViewModel:ViewModel () {
    val comparador: LiveData<Comparacion> get() = _resultado
    private var _resultado: MutableLiveData<Comparacion> = MutableLiveData<Comparacion>(Comparacion("","",""))
    fun actualizarComparacion(){
        var tx1= (_resultado.value?.texto1 ?: "")
        Comparacion("","","")
    }
}