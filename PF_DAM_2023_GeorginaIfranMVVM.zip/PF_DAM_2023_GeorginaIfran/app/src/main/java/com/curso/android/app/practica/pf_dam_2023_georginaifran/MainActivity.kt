package com.curso.android.app.practica.pf_dam_2023_georginaifran

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    }
    fun comparar(view:View){
        var cadena1:EditText?= this.findViewById(R.id.texto1)
        var cadena2:EditText?= this.findViewById(R.id.texto2)
        var cad1=cadena1?.text.toString()
        var cad2=cadena2?.text.toString()
        var cadenaRespuesta:TextView?=findViewById(R.id.resultadoComparacion)
        if (cad1?.equals(cad2) == true) cadenaRespuesta?.text = "$cad1 y $cad2 son iguales" else cadenaRespuesta?.text = "$cad1 y $cad2 no son iguales"
    }

}
