package com.curso.android.app.practica.pf_dam_2023_georginaifran

data class Comparacion(var texto1: String, var texto2:String, var resultadoComparacion:String)
