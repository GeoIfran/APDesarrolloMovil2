package com.curso.android.app.practica.pf_dam_2023_georginaifran

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    var cadena1:EditText?=null
    var cadena2:EditText?=null
    var cadenaRespuesta:TextView?=null
    var cad1=""
    var cad2=""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    }
    fun comparar(view:View){
        cadena1= this.findViewById(R.id.texto1)
        cadena2= this.findViewById(R.id.texto2)
        cad1=cadena1?.text.toString()
        cad2=cadena2?.text.toString()
        cadenaRespuesta=findViewById(R.id.resultadoComparacion)
        if (cad1?.equals(cad2) == true) cadenaRespuesta?.text = "$cad1 y $cad2 son iguales" else cadenaRespuesta?.text = "$cad1 y $cad2 no son iguales"
    }
}
